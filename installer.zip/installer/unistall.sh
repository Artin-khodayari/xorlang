echo "set the root mode"
rm -rf /opt/xorlang
echo "uninstalling is finished"
