echo "set the root mode"
mkdir /opt/xorlang
mv xorlang /opt/xorlang
echo "installing is finished"
